# Morph MCP

Supercharge your coding agent. One MCP with two specialized tools for faster edits and smarter retrieval.

## Tools

| Tool | What it does |
|------|-------------|
| `edit_file` | Apply code changes at 10,500+ tokens/sec with 98% accuracy |
| `warpgrep_codebase_search` | Sub-agent that runs parallel grep/read operations to find relevant code |
| `warpgrep_github_search` | Search any public GitHub repo by URL or `owner/repo` shorthand |

All three tools are always exposed. Clients can manage tool visibility on their side.

## Quick Start

### Claude Code

```bash
claude mcp add morph-mcp -e MORPH_API_KEY=sk-xxx -- npx -y @morphllm/morphmcp
```

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "morph-mcp": {
      "command": "npx",
      "args": ["-y", "@morphllm/morphmcp"],
      "env": {
        "MORPH_API_KEY": "sk-xxx"
      }
    }
  }
}
```

### VS Code

Add to `.vscode/mcp.json`:

```json
{
  "mcp": {
    "servers": {
      "morph-mcp": {
        "command": "npx",
        "args": ["-y", "@morphllm/morphmcp"],
        "env": {
          "MORPH_API_KEY": "sk-xxx"
        }
      }
    }
  }
}
```

## How the Tools Work

### edit_file

Applies code edits using Morph's Fast Apply model. The agent sends partial code with `// ... existing code ...` placeholders, and Fast Apply merges it into the full file.

```
Input:
  path: "src/api.ts"
  code_edit: |
    export async function fetchData(endpoint: string) {
      // ... existing code ...
      const response = await fetch(endpoint, { 
        headers,
        timeout: 5000  // added timeout
      });
      // ... existing code ...
    }
  instruction: "Add 5 second timeout to fetch call"

Output: Git-style unified diff showing exactly what changed
```

### warpgrep_codebase_search

A search sub-agent that explores your codebase autonomously. Give it a problem and it runs multiple grep/read operations to locate relevant files and line ranges.

```
Input:
  search_string: "Find where authentication tokens are validated"
  repo_path: "/Users/me/project"
  search_type: "default"  # optional: "default" or "node_modules"

Output: List of files with specific line ranges + actual code content
```

## Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `MORPH_API_KEY` | Your API key from [morphllm.com](https://morphllm.com) | Required |
| `MORPH_API_URL` | Override Morph API base URL for custom proxies | `https://api.morphllm.com` |
| `MORPH_WARP_GREP_TIMEOUT` | Timeout for warp grep model calls in ms | `30000` |

## Get an API Key

1. Sign up at [morphllm.com](https://morphllm.com)
2. Go to dashboard → API Keys
3. Keys start with `sk-` or `morph-`

## Links

- [Documentation](https://docs.morphllm.com)
- [MCP Quickstart](https://docs.morphllm.com/mcpquickstart)

## License

MIT

<!-- Published with npm Trusted Publishing -->
