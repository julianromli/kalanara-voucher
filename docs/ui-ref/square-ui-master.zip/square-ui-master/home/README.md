## Credits

This site is built using the [Commit template](https://tailwindcss.com/plus/templates/commit) from Tailwind Plus, used under the Tailwind Plus license.

The use of this template to showcase my original UI template creations has been approved by the Tailwind team.